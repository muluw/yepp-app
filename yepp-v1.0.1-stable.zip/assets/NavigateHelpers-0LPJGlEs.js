import{A as t,r as a}from"./index-J8-_cj39.js";function s(){const e=t();return a.useEffect(()=>{e(-1)},[]),null}export{s as default};
