import{t as e,r as a}from"./index-1hof3-cN.js";function s(){const t=e();return a.useEffect(()=>{t(-1)},[]),null}export{s as default};
