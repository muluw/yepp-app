function c(a) {
	return decodeURIComponent(a.replace(/\s+/g, "").replace(/[0-9A-F]{2}/g, "%$&"));
}

let d = 0,
	e = 0;

MDS.init((a => {
	const { event: f, data: g } = a;
	if ("MDS_TIMER_10SECONDS" === f && (d = g.timemilli), "MDSCOMMS" === f) {
		const { appTime: h } = JSON.parse(g.message);
		e = h;
	}
	if ("inited" === f) {
		const i = `
			CREATE TABLE IF NOT EXISTS yeppcomm (
				id BIGINT AUTO_INCREMENT, 
				roomname VARCHAR(160) NOT NULL, 
				publickey VARCHAR(512) NOT NULL, 
				username VARCHAR(160) NOT NULL, 
				type VARCHAR(64) NOT NULL, 
				message VARCHAR(512) NOT NULL, 
				filedata CLOB(256K) NOT NULL, 
				customid VARCHAR(128) NOT NULL UNIQUE, 
				state VARCHAR(128) NOT NULL DEFAULT '', 
				read INT NOT NULL DEFAULT 0, 
				date BIGINT NOT NULL
			)
		`;
		MDS.sql(i, (() => {}));

		const t = `
			CREATE TABLE IF NOT EXISTS txn_cache (
				id BIGINT AUTO_INCREMENT, 
				tokenid VARCHAR(75) NOT NULL, 
				address VARCHAR(75) NOT NULL, 
				rcppubk VARCHAR(160), 
				rcpaddr VARCHAR(160), 
				atcreatedblock BIGINT, 
				pos VARCHAR(10) DEFAULT 'sell', 
				PRIMARY KEY (id)
			)
		`;
		MDS.sql(t, (() => {}));
	} else if ("MAXIMA" === f && "yepp" === g.application) {
		const j = g.from,
			k = c(g.data.slice(2));
		let l;
		try {
			l = JSON.parse(k);
		} catch (m) {
			return void MDS.log(m);
		}

		if ("maxitalk" === l.branch) {
			if ("delmsg" === l.type) {
				const n = l.roomname,
					o = l.customid,
					p = `UPDATE yeppcomm SET state='trash' WHERE roomname='${n}' AND customid='${o}'`;
				MDS.sql(p, () => {}).catch((q) => {
					MDS.log(q);
				});
			} else if ("editmsg" === l.actionType) {
				const updatedMessage = encodeURIComponent(l.message).replace(/'/g, "%27");
				const updateQuery = `
				UPDATE yeppcomm 
				SET message='${updatedMessage}'
				WHERE customid='${l.customid}'
				`;
				MDS.sql(updateQuery, () => {}).catch((q) => {
				MDS.log(q);
				});
			} else {
				const r = encodeURIComponent(l.message).replace(/'/g, "%27"),
					mergeQuery = `
						MERGE INTO yeppcomm AS target
						USING (VALUES 
							('${l.roomname}', '${j}', '${l.username}', '${l.type}', '${r}', '${l.filedata}', '${l.customid}', ${Date.now()})
						) AS source (roomname, publickey, username, type, message, filedata, customid, date)
						ON target.customid = source.customid
						WHEN MATCHED THEN 
							UPDATE SET 
								roomname = source.roomname, 
								publickey = source.publickey, 
								username = source.username, 
								type = source.type, 
								message = source.message, 
								filedata = source.filedata, 
								date = source.date
						WHEN NOT MATCHED THEN 
							INSERT (roomname, publickey, username, type, message, filedata, customid, date) 
							VALUES (source.roomname, source.publickey, source.username, source.type, source.message, source.filedata, source.customid, source.date);
					`;
				MDS.sql(mergeQuery);
				if (d > e + 3e5) {
					MDS.notify(`${l.username}\n${decodeURIComponent(l.message)}`);
				}
			}
		}
	}
}));
