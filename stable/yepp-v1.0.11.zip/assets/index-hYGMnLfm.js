import{A as t,r as a}from"./index-CkW51VGS.js";function s(){const e=t();return a.useEffect(()=>{e(-1)},[]),null}export{s as default};
